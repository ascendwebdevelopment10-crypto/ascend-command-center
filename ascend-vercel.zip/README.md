# Ascend Command Center

Sales-ops dashboard for the agency launch: Scope Guard, Agency Scorecard,
Clients, and Handoff Briefs. Built with Vite + React.

## Deploy to Vercel (2 minutes)

**Option A — drag & drop**
1. Run `npm install` then `npm run build` (creates a `dist/` folder).
2. Go to vercel.com → Add New → Project → drag this folder in.

**Option B — CLI**
1. `npm i -g vercel`
2. From this folder: `vercel` (follow the prompts), then `vercel --prod`.

**Option C — Git**
Push this folder to a GitHub repo and import it at vercel.com/new.

## Turn on AI (Scope Guard, upsells, weekly read)
The AI features call a serverless function at `/api/ai`, which needs a key.
In Vercel → your project → Settings → Environment Variables, add:

    ANTHROPIC_API_KEY = sk-ant-...   (from console.anthropic.com)

Redeploy after adding it. Without the key, the app runs fine — the AI
buttons just show a "not configured" message. Your data saves in the
browser either way.
